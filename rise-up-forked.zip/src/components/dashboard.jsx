import React from "react";

function Dashboard(props) {
  const changetheme = () => {
    props.oncolor();
  };

  const buttonStyle = {
    backgroundColor: props.colorno ? "blue" : "#4caf50",
  };

  return (
    <header>
      <h1>Rise Up</h1>
      <nav>
        <ul>
          <li>
            <a href="#">Home</a>
          </li>
          <li>
            <a href="#">About Us</a>
          </li>
          <li>
            <a href="#">Shop</a>
          </li>
          <li>
            <a href="#">My Profile</a>
          </li>
        </ul>
      </nav>
      <div className="header-right">
        <button
          style={buttonStyle}
          className="light-button"
          onClick={changetheme}
        >
          Light Mode
        </button>
        <button className="login-button">Login</button>
      </div>
    </header>
  );
}
export default Dashboard;
