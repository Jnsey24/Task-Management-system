import React from "react";
function Description() {
  return (
    <div className="descriptclass">
      <p className="introduction">
        <div> A Website to Bring the Best of you </div>
        <div> Start your Day with us </div>
        <div> Complete your Daily Tasks</div>
      </p>
    </div>
  );
}
export default Description;
