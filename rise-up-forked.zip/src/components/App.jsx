import React, { useState, useEffect } from "react";
import Dashboard from "./dashboard";
import Description from "./Description";
import Note from "./Note";
import Footer from "./Footer";
import Task from "./tasks";

function App() {
  const [colorno, setColor] = useState(0);
  const [tasks, settasks] = useState([
    { id: 0, title: "Fixed Task 1", alarm: "5:37 PM", isFixed: true },
    { id: 1, title: "Fixed Task 2", alarm: "5:40 PM", isFixed: true },
  ]);
  const [error, setError] = useState("");
  const [score, setScore] = useState(0);
  const [completedTasks, setCompletedTasks] = useState(0);
  const [coinMessage, setCoinMessage] = useState("");

  const changecolor = () => {
    setColor((prev) => !prev);
  };

  const bodycolor = {
    backgroundColor: colorno ? "black" : "#f1f4dc",
    color: colorno ? "white" : "black",
    height: "100vh",
  };

  useEffect(() => {
    if (tasks.length > 0 && completedTasks === tasks.length) {
      setScore((prevScore) => prevScore + 1);
      setCoinMessage("You gained one coin!");
      setTimeout(() => setCoinMessage(""), 3000);
      setCompletedTasks(0); // Reset completed tasks count for the next day
    }
  }, [completedTasks, tasks]);

  function addtask(task) {
    settasks((prev) => {
      return [...prev, { ...task, id: prev.length, isFixed: false }];
    });
  }

  function handledelete(id) {
    settasks((prev) => {
      return prev.filter((item) => item.id !== id);
    });
    // Update the completed tasks count correctly if a completed task is deleted
    setCompletedTasks((prev) => (prev > 0 ? prev - 1 : 0));
  }

  function handledone(id) {
    const task = tasks.find((task) => task.id === id);
    const timeoftask = task.alarm;

    const date = new Date();
    const currentHours = date.getHours();
    const currentMinutes = date.getMinutes();

    const [taskTime, period] = timeoftask.split(" ");
    const [taskHours, taskMinutes] = taskTime.split(":").map(Number);

    let taskHours24 = taskHours;
    if (period.toLowerCase() === "pm" && taskHours < 12) {
      taskHours24 += 12;
    } else if (period.toLowerCase() === "am" && taskHours === 12) {
      taskHours24 = 0;
    }

    const currentTimeInMinutes = currentHours * 60 + currentMinutes;
    const taskTimeInMinutes = taskHours24 * 60 + taskMinutes;

    const timeDifference = currentTimeInMinutes - taskTimeInMinutes;

    if (timeDifference < 0) {
      setError("Sorry! Still time is there");
      setTimeout(() => setError(""), 3000); // Clear error message after 3 seconds
    } else if (timeDifference <= 10) {
      setCompletedTasks((prev) => prev + 1);
      handledelete(id);
    } else {
      setError("Sorry! It's too late");
      setTimeout(() => setError(""), 3000); // Clear error message after 3 seconds
    }
  }

  return (
    <div style={bodycolor} className="container">
      <Dashboard oncolor={changecolor} colorno={colorno} />
      <Description />
      <Task addnew={addtask} />
      {tasks.map((item, index) => (
        <Note
          key={index}
          id={item.id}
          title={item.title}
          alarm={item.alarm}
          isFixed={item.isFixed}
          ondelete={handledelete}
          oncheck={handledone}
        />
      ))}
      {error && <p style={{ color: "red" }}>{error}</p>}
      <Footer />
      <div>
        {coinMessage && <p style={{ color: "green" }}>{coinMessage}</p>}
      </div>
    </div>
  );
}

export default App;
